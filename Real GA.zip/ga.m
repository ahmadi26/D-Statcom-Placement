clc;
clear;
close all;

%% Problem Definition

global NFE
global pd1 pd2 pd3 qd0
global vmin vmax imax
global Mu landa T Kc Ke CostDSTAT B n
global sb vb nbus
global nb accuracy maxiter pd qd Beta b1 b2 z dl DataFileName

NFE=0;

nbus=33;

eval(['DataFileName=''data_',num2str(nbus),''';']);


%% Method 2
[nb,accuracy,maxiter,pd,qd,Beta,b1,b2,z,sb,vb]=pre_pf_bflf_2;
% pd, qd and z  ---> pu

%% Data
imax=520/(sb/vb*1000);
vmin=0.9;
vmax=1.1;
CostDSTATCOM=50;
n=30;
B=0.1;
Ke=0.06;
landa=2;
Mu=1;
T=[2000 5260 1500];
Kc=[0.22831,  0.60046,  0.17123];
CostDSTATCOMyear=CostDSTATCOM*((1+B)^n*B)/((1+B)^n-1);
%%

pd0=pd;
qd0=qd;


pd1=pd0;
pd2=pd0*1.3;
pd3=pd0*1.6;

%%
CostFunction=@(x) ObjFun(x);     % Cost Function

nVar=4;             % Number of Decision Variables

VarSize=[1 nVar];   % Decision Variables Matrix Size

VarMin=[1.5,                 zeros(1,nVar-1)];         % Lower Bound of Variables
VarMax=[nbus+0.4999999, 4000*ones(1,nVar-1)];         % Upper Bound of Variables


%% GA Parameters

MaxNFE=40e3;      % Maximum Number of Function Evaluations

nPop=100;        % Population Size

pc=0.8;                 % Crossover Percentage
nc=2*round(pc*nPop/2);  % Number of Offsprings (Parnets)

pm=0.3;                 % Mutation Percentage
nm=round(pm*nPop);      % Number of Mutants

gamma=0.05;

mu=0.02;         % Mutation Rate

MaxIt=ceil(MaxNFE/(nc+nm));

% ANSWER=questdlg('Choose selection method:','Genetic Algorith',...
%     'Roulette Wheel','Tournament','Random','Roulette Wheel');

ANSWER='Roulette Wheel';
UseRouletteWheelSelection=strcmp(ANSWER,'Roulette Wheel');
UseTournamentSelection=strcmp(ANSWER,'Tournament');
UseRandomSelection=strcmp(ANSWER,'Random');

if UseRouletteWheelSelection
    beta=8;         % Selection Pressure
end

if UseTournamentSelection
    TournamentSize=3;   % Tournamnet Size
end

pause(0.1);

%% Initialization

empty_individual.Position=[];
empty_individual.Cost=[];

pop=repmat(empty_individual,nPop,1);

for i=1:nPop
    
    % Initialize Position
    pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
    
    % Evaluation
    pop(i).Cost=CostFunction(pop(i).Position);
    
end

% Sort Population
Costs=[pop.Cost];
[Costs, SortOrder]=sort(Costs);
pop=pop(SortOrder);

% Store Best Solution
BestSol=pop(1);
BestOF=BestSol.Cost;

% Array to Hold Best Cost Values
BestCost=zeros(MaxIt,1);

% Store Cost
WorstCost=pop(end).Cost;

% Array to Hold Number of Function Evaluations
nfe=zeros(MaxIt,1);


%% Main Loop
it=0;
while NFE<MaxNFE
    it=it+1;  
    % Calculate Selection Probabilities
    if UseRouletteWheelSelection
        P=exp(-beta*Costs/WorstCost);
        P=P/sum(P);
    end
    
    % Crossover
    popc=repmat(empty_individual,nc/2,2);
    for k=1:nc/2
        
        % Select Parents Indices
        if UseRouletteWheelSelection
            i1=RouletteWheelSelection(P);
            i2=RouletteWheelSelection(P);
        end
        if UseTournamentSelection
            i1=TournamentSelection(pop,TournamentSize);
            i2=TournamentSelection(pop,TournamentSize);
        end
        if UseRandomSelection
            i1=randi([1 nPop]);
            i2=randi([1 nPop]);
        end

        % Select Parents
        p1=pop(i1);
        p2=pop(i2);
        
        % Apply Crossover
        [popc(k,1).Position, popc(k,2).Position]=...
            Crossover(p1.Position,p2.Position,gamma,VarMin,VarMax);
        
        % Evaluate Offsprings
        popc(k,1).Cost=CostFunction(popc(k,1).Position);
        popc(k,2).Cost=CostFunction(popc(k,2).Position);
        
    end
    popc=popc(:);
    
    
    % Mutation
    popm=repmat(empty_individual,nm,1);
    for k=1:nm
        
        % Select Parent
        i=randi([1 nPop]);
        p=pop(i);
        
        % Apply Mutation
        popm(k).Position=Mutate(p.Position,mu,VarMin,VarMax);
        
        % Evaluate Mutant
        popm(k).Cost=CostFunction(popm(k).Position);
        
    end
    
    % Create Merged Population
    pop=[pop
         popc
         popm];
     
    % Sort Population
    Costs=[pop.Cost];
    [Costs, SortOrder]=sort(Costs);
    pop=pop(SortOrder);
    
    % Update Worst Cost
    WorstCost=max(WorstCost,pop(end).Cost);
    
    % Truncation
    pop=pop(1:nPop);
    Costs=Costs(1:nPop);
    
    % Store Best Solution Ever Found
    BestSol=pop(1);
    BestOF=BestSol.Cost;
    
    % Store Best Cost Ever Found
    BestCost(it)=BestSol.Cost;
    
    % Store NFE
    nfe(it)=NFE;
    
    % Show Iteration Information
    disp(['Iteration ' num2str(it) ': NFE = ' num2str(nfe(it)) ', Best OF = ' num2str(BestCost(it))]);
    
end

%% Results
finalizer_GA
displayer_GA