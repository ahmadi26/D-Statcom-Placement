
figure;
if nfe(it)==0
      it=it-1;
end
plot(nfe(1:it),BestCost(1:it),'LineWidth',2);
xlim([0 NFE])
xlabel('NFE');
ylabel('OF');
title('GA Method')

[of,out]=CostFunction(BestSol.Position);
[of0,out0]=CostFunction(BestSol.Position.*[1 0 0 0]);

save(['Res-',num2str(nbus),'-GA-',num2str(round(BestOF)),'.mat'])
