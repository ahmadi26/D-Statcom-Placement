function [nb,accuracy,maxiter,pd,qd,Beta,b1,b2,z,sb,vb]=pre_pf_bflf_2

global DataFileName
[ld,bd,sb,vb]=eval(DataFileName);
pd=bd(:,2)/sb;   % pu
qd=bd(:,3)/sb;   % pu
z = ld(:,3) + 1j*ld(:,4);


b1=ld(:,1);      % Sending buses
b2=ld(:,2);      % Recieving buses
nl=length(b1);   % Number of lines
nb=nl+1;         % Number of buses
M=zeros(nl,nb);  % Branch and node matrix


%%
for i=1:nl
    M(i,b1(i))=-1;
    M(i,b2(i))=1;
end

%%
lb=find(min(M)==0 & max(M)==1); % last buses
nlb=length(lb);
routes=cell(nlb,1); %%%%
db=cell(nb,1);  % Down Buses
for i=1:nlb
    nr=lb(i);
    routes{i}=nr; %%%%
    bra=find(M(:,nr)== 1);
    while ~isempty(bra)
        ns=find(M(bra,:)==-1);
        if ~ismember(nr,db{ns})
            db{ns}=[db{ns} , nr];
        end
        nr=ns;
        routes{i}=[routes{i} , nr]; %%%%
        bra=find(M(:,nr)== 1);
    end
end

%%
Beta=cell(nb,1);    % Set of all down buses
for i=1:nb
    for j=1:nlb
        nij=find(routes{j}==i);
        Beta{i} = unique([Beta{i} , routes{j}(1:nij-1)]);
    end
end

maxiter=100;
accuracy=1e-14;