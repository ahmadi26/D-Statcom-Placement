function y=IA_Mutate(x,c,mul,VarMin,VarMax,VarSpan,BestC,nVar)

    
    y=x;
    y=y + mul*c/BestC*randn(1,nVar).*VarSpan*0.1; 
    
    y=max(y,VarMin);
    y=min(y,VarMax);

end

