clc;
clear;
close all;

%% Problem Definition

global NFE
global pd1 pd2 pd3 qd0
global vmin vmax imax
global Mu landa T Kc Ke CostDSTATCOM B n
global sb vb nbus
global nb accuracy maxiter pd qd Beta b1 b2 z dl DataFileName

NFE=0;

nbus=33;

eval(['DataFileName=''data_',num2str(nbus),''';']);


%% Method 2
[nb,accuracy,maxiter,pd,qd,Beta,b1,b2,z,sb,vb]=pre_pf_bflf_2;
% pd, qd and z  ---> pu

%% Data
imax=520/(sb/vb*1000);
vmin=0.9;
vmax=1.1;
CostDSTATCOM=50;
n=30;
B=0.1;
Ke=0.06;
landa=2;
Mu=1;
T=[2000 5260 1500];
Kc=[0.22831,  0.60046,  0.17123];

mul=0.1;
%%

pd0=pd;
qd0=qd;


pd1=pd0;
pd2=pd0*1.3;
pd3=pd0*1.6;

%%
CostFunction=@(x) ObjFun(x);     % Cost Function

nVar=4;             % Number of Decision Variables

VarSize=[1 nVar];   % Decision Variables Matrix Size

VarMin=[1.5,                 zeros(1,nVar-1)];         % Lower Bound of Variables
VarMax=[nbus+0.4999999, 4000*ones(1,nVar-1)];         % Upper Bound of Variables
VarSpan=VarMax-VarMin;

%% GA Parameters

MaxNFE=40e3;      % Maximum Number of Function Evaluations

nPop=50;        % Population Size

nCol=nPop*2;

nTour=5;

MaxAge=20;

mu=0.02;

MaxIt=ceil(MaxNFE/nCol);

%% Initialization

empty_Ab.Position=[];
empty_Ab.Cost=[];
empty_Ab.Age=0;


AB=repmat(empty_Ab,nPop,1);
Clones1=repmat(empty_Ab,nCol,1);
Clones=repmat(empty_Ab,nCol,1);
AllClones=[Clones;AB];

for i=1:nPop
    
    % Initialize Position
    AB(i).Position=unifrnd(VarMin,VarMax,VarSize);
        
    % Evaluation
    AB(i).Cost=CostFunction(AB(i).Position);
    
end

% Sort Population
Costs=[AB.Cost];
[Costs, SortOrder]=sort(Costs);
AB=AB(SortOrder);

% Store Best Solution
BestSol=AB(1);
BestOF=BestSol.Cost;

% Array to Hold Best Cost Values
BestCost=zeros(MaxIt,1);

% Store Cost
WorstCost=AB(end).Cost;

% Array to Hold Number of Function Evaluations
nfe=zeros(MaxIt,1);


%% Main Loop
it=0;
while NFE<MaxNFE
    it=it+1;
    Costs=[AB.Cost];
    Affinity=1./Costs;
    ncol=round(nCol*Affinity/sum(Affinity));
    ncol(1)=ncol(1)+nCol-sum(ncol);
    nn=1;
    Clones=Clones1;
    for i=1:nPop
          AB(i).Age=AB(i).Age+1;
          for j=1:ncol(i)
                Clones(nn).Position=AB(i).Position;
                Clones(nn).Cost=AB(i).Cost;
                nn=nn+1;
          end
    end
    
    for i=1:nCol
          
%           % IA Mutate
          Clones(i).Position=IA_Mutate(Clones(i).Position,Clones(i).Cost,...
                mul,VarMin,VarMax,VarSpan,AB(1).Cost,nVar);
          
%           % GA Mutate
%           Clones(i).Position=Mutate(Clones(i).Position,mu,VarMin,VarMax);

          Clones(i).Cost=CostFunction(Clones(i).Position);
    end
    
    % Aging Operator
    ages=[AB.Age]; 
    aged_ind=ages>MaxAge;
    AB(aged_ind)=[];
    Clones2=[Clones;AB];
    
    % Tournament
    nCol2=length(Clones2);
    TourSuccess=zeros(nCol2,1);
    for i=1:nCol2
          for j=1:nTour
                i2=randi([1,nCol2]);
                if Clones2(i).Cost<Clones2(i2).Cost
                      TourSuccess(i)=TourSuccess(i)+1;
                end
          end
    end
    [~,ind]=sort(TourSuccess,'descend');
    AB=Clones2(ind(1:nPop));
    
    % Sort Population
    Costs=[AB.Cost];
    [Costs, SortOrder]=sort(Costs);
    AB=AB(SortOrder);
    
    if AB(1).Cost<BestSol.Cost
          % Store Best Solution Ever Found
          BestSol=AB(1);
          BestOF=BestSol.Cost;
    end
    
    % Store Best Cost Ever Found
    BestCost(it)=BestSol.Cost;
    
    % Store NFE
    nfe(it)=NFE;
        
    % Show Iteration Information
    disp(['Iteration ' num2str(it) ': NFE = ' num2str(NFE) ', Best OF = ' num2str(BestCost(it))]);
    
end

%% Results
finalizer_IA
displayer_IA